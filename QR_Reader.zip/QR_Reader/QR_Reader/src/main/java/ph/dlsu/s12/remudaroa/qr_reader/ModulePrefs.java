package ph.dlsu.s12.remudaroa.qr_reader;

import android.content.Context;
import android.content.SharedPreferences;

public class ModulePrefs {

    private SharedPreferences locationPreferences;
    private final String PREFS = "locationPreferences";

    public ModulePrefs(Context context)
    {
        locationPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void saveStringPreferences(String key, String value) {
        SharedPreferences.Editor prefsEditor = locationPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();
    }

    public void removePreferences(){
        SharedPreferences.Editor prefsEditor = locationPreferences.edit();
        prefsEditor.clear();
        prefsEditor.commit();
    }

    public String getStringPreferences(String key) {
        return (locationPreferences.getString(key, "Nothing Saved"));
    }

}