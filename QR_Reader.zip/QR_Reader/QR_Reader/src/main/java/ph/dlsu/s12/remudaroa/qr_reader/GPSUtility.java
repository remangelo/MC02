package ph.dlsu.s12.remudaroa.qr_reader;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

public class GPSUtility {

    private Context mContext;
    private LocationManager locationManager;
    private Activity activity;

    private boolean isGPSEnabled;
    private boolean isNetworkEnabled;

    private static final int PERMISSION_REQUEST_FINE_CODE = 1;
    private static final int PERMISSION_REQUEST_COARSE_CODE = 2;

    private ModulePrefs modulePrefs;

    private final LocationListener satelliteGPSListener
            = new LocationListener() {
        @Override
        public void onLocationChanged(Location newLocation) {
            locationManager.removeUpdates(this);

            modulePrefs = new ModulePrefs(activity.getApplicationContext());

            modulePrefs.removePreferences();
            modulePrefs.saveStringPreferences("latitude", String.valueOf(newLocation.getLatitude()));
            modulePrefs.saveStringPreferences("longitude", String.valueOf(newLocation.getLongitude()));

            Log.d("GPS Location", "GPS Data["
                    + newLocation.getProvider() + "]["
                    + newLocation.getLatitude() + "]["
                    + newLocation.getLongitude() + "]["
                    + newLocation.getSpeed() + "]["
                    + newLocation.getTime() + "]");
        } // end onLocationChanged

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    private final LocationListener networkGPSListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location newLocation) {
            locationManager.removeUpdates(this);

            modulePrefs = new ModulePrefs(activity.getApplicationContext());

            modulePrefs.removePreferences();
            modulePrefs.saveStringPreferences("latitude", String.valueOf(newLocation.getLatitude()));
            modulePrefs.saveStringPreferences("longitude", String.valueOf(newLocation.getLongitude()));
            Log.d("GPS Location", "Network ["
                    + newLocation.getProvider() + "]["
                    + newLocation.getLatitude() + "]["
                    + newLocation.getLongitude() + "]["
                    + newLocation.getSpeed() + "]["
                    + newLocation.getTime() + "]");
        } // end onLocationChanged

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    public GPSUtility(Context context, Activity activity) {
        mContext = context;
        locationManager = (LocationManager) mContext
                .getSystemService(Service.LOCATION_SERVICE);
        this.activity = activity;
    } // end constructor

    public GPSUtility( Context context ) {
        mContext = context;
        locationManager = ( LocationManager )mContext.getSystemService(Service.LOCATION_SERVICE);
    }


    public void getGPSLocationOnce(){
        isGPSEnabled = locationManager
                .isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnabled = locationManager
                .isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if (!isGPSEnabled && !isNetworkEnabled) {
            // error handling
            // in no network and no gps
        } else{
            if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED){
                String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION};
                activity.requestPermissions(permissions, PERMISSION_REQUEST_FINE_CODE);
            }
            if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                String[] permissions = {Manifest.permission.ACCESS_COARSE_LOCATION};
                activity.requestPermissions(permissions, PERMISSION_REQUEST_COARSE_CODE);
            }
            if (isGPSEnabled) {
                locationManager
                        .requestLocationUpdates(LocationManager.GPS_PROVIDER,
                                5000, // time
                                1, // distance in meters
                                satelliteGPSListener);
            }
            if( isNetworkEnabled ) {
                locationManager
                        .requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                                5000, // time
                                1, // distance in meters
                                networkGPSListener );

            }
        }
    }


}
