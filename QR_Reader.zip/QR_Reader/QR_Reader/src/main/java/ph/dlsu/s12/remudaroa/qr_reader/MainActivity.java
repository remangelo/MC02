package ph.dlsu.s12.remudaroa.qr_reader;


import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private String completeInfo = "", name = "", address = "", age = "", contactNum = "", location = "", DateTime = "";
    private CodeScanner mCodeScanner;
    private double dLatitude = 0, dLongitude =0;
    private String sLatitude = "", sLongitude = "";
    private TextView TV_scan;

    private ModulePrefs modulePrefs;

    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("CovidTracker");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TV_scan = findViewById(R.id.TV_scan);

        //user has not given permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED){

            GPSUtility gps = new GPSUtility(getApplicationContext(), MainActivity.this);
            gps.getGPSLocationOnce();
            scanCode();
        } else {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.INTERNET}, 1);
        }


    }

    private void scanCode(){
        CodeScannerView scannerView = findViewById(R.id.camera_view);
        mCodeScanner = new CodeScanner(this, scannerView);
        mCodeScanner.setDecodeCallback(result -> runOnUiThread(new Runnable() {
            @Override
            public void run() {

                //Toast.makeText(MainActivity.this, result.getText(), Toast.LENGTH_SHORT).show();

                modulePrefs = new ModulePrefs(getApplicationContext());

                sLatitude = modulePrefs.getStringPreferences("latitude");
                sLongitude = modulePrefs.getStringPreferences("longitude");

                dLatitude = Double.parseDouble(sLatitude);
                dLongitude = Double.parseDouble(sLongitude);

                Geocoder gcd = new Geocoder(getApplicationContext(), Locale.getDefault());
                List<Address> addresses = null;
                try {
                    addresses = gcd.getFromLocation(dLatitude, dLongitude, 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (addresses.size() > 0) {
                    location = addresses.get(0).getAddressLine(0);
                    System.out.println(addresses.get(0).getAddressLine(0));
                }

                TV_scan.setText("Tap scanner to scan again");

                Date date = Calendar.getInstance().getTime();
                SimpleDateFormat df = new SimpleDateFormat("E MM-dd-yyyy hh:mm:ss a");
                DateTime = String.valueOf(df.format(date));

                completeInfo = result.getText();
                String[] parts = result.getText().split("//");
                name = parts[0];
                address = parts [1];
                contactNum = parts[2];
                age = parts[3];

               DatabaseReference covidRef = ref.child("locationHistory");

               String key = covidRef.push().getKey();

                covidRef.child(key).setValue(new CovidTracing(name, address, contactNum, age, location, DateTime), new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                    if (databaseError != null) {
                        System.out.println("Data could not be saved " + databaseError.getMessage());
                    } else {
                        System.out.println("Data saved successfully.");
                    }
                }
                });

            }
        }));
        scannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCodeScanner.startPreview();
                TV_scan.setText("Scanning for a QR Code...");
            }
        });
    }
        @Override
        public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            switch (requestCode) {
                case 0:
                    boolean isPerpermissionForAllGranted = false;
                    if (grantResults.length > 0 && permissions.length == grantResults.length) {
                        for (int i = 0; i < permissions.length; i++) {
                            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                                isPerpermissionForAllGranted = true;
                            } else {
                                isPerpermissionForAllGranted = false;
                            }
                        }

                    } else {
                        isPerpermissionForAllGranted = true;
                    }
                    if (isPerpermissionForAllGranted) {
                        GPSUtility gps = new GPSUtility(getApplicationContext(), MainActivity.this);
                        gps.getGPSLocationOnce();
                        scanCode();
                    }
                    break;
            }
        }

    @Override
    protected void onResume() {
        super.onResume();
        mCodeScanner.startPreview();
    }

    @Override
    protected void onPause() {
        mCodeScanner.releaseResources();
        super.onPause();
    }



}